iostat -n0 -w1 > /Volumes/ramdisk/cpu
